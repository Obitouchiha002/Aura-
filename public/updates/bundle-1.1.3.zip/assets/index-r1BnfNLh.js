import{r as e}from"./index-CvGGFCze.js";const i=e("FileOpener");export{i as FileOpener};
