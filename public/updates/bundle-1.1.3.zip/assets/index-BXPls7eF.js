const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BL1qRT28.js","assets/index-CvGGFCze.js","assets/index-DT8rhUW6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CvGGFCze.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-BL1qRT28.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
