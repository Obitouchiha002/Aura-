import{c as r,s as e}from"./flowDiagram-UKHOOZJN-D42-Pt5Q.js";import{_ as a}from"./mermaid.core-mrfdsQkO.js";import"./chunk-5VM5RSS4-BcHo3LuM.js";import"./chunk-XXDRQBXY-DXans53i.js";import"./chunk-KBJHAD2P-CceqwypX.js";import"./chunk-2GRJ4B5K-C6Jn4LWV.js";import"./channel-9mhkvem6.js";import"./index-CvGGFCze.js";import"./step-azJovCkv.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
