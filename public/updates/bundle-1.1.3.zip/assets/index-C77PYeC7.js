const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C11XhzjJ.js","assets/index-CvGGFCze.js","assets/index-DT8rhUW6.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-CvGGFCze.js";const _=p("App",{web:()=>r(()=>import("./web-C11XhzjJ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
