import{r as e}from"./index-CmsCL9p0.js";const i=e("FileOpener");export{i as FileOpener};
