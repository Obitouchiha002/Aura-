const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CGnMFhTD.js","assets/index-CmsCL9p0.js","assets/index-DT8rhUW6.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-CmsCL9p0.js";const _=p("App",{web:()=>r(()=>import("./web-CGnMFhTD.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
