const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DP8gIo6p.js","assets/index-CmsCL9p0.js","assets/index-DT8rhUW6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CmsCL9p0.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-DP8gIo6p.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
