import{c as r,s as e}from"./flowDiagram-UKHOOZJN-BcZNHPyR.js";import{_ as a}from"./mermaid.core-Z7ZlBxNf.js";import"./chunk-5VM5RSS4-ooWvbZ_r.js";import"./chunk-XXDRQBXY-DWuNo8hh.js";import"./chunk-KBJHAD2P-YE828Zzn.js";import"./chunk-2GRJ4B5K-CeMwmzP4.js";import"./channel-sECOdEFd.js";import"./index-CmsCL9p0.js";import"./step-azJovCkv.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
