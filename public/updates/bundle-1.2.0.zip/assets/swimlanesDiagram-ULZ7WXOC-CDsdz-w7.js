import{c as r,s as e}from"./flowDiagram-UKHOOZJN-BzxBMi7S.js";import{_ as a}from"./mermaid.core-0X9j_HI8.js";import"./chunk-5VM5RSS4-IgTW6Zv-.js";import"./chunk-XXDRQBXY-CV5Z9_J8.js";import"./chunk-KBJHAD2P-BSbPRA7K.js";import"./chunk-2GRJ4B5K-B5ZcaS67.js";import"./channel-bbvMtTvQ.js";import"./index-BJvcunn3.js";import"./step-D2nkEwto.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
