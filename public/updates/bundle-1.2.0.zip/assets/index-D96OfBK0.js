const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DVD0b_TK.js","assets/index-BJvcunn3.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BJvcunn3.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-DVD0b_TK.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
