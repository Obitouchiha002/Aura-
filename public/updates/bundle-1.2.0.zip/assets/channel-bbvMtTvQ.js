import{U as a,R as n}from"./mermaid.core-0X9j_HI8.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
