import{r as e}from"./index-BJvcunn3.js";const i=e("FileOpener");export{i as FileOpener};
