const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cm1iYvKB.js","assets/index-BJvcunn3.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BJvcunn3.js";const _=p("App",{web:()=>r(()=>import("./web-Cm1iYvKB.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
