import{c as r,s as e}from"./flowDiagram-UKHOOZJN-BBUhNG7c.js";import{_ as a}from"./mermaid.core-C0Ym1gAH.js";import"./chunk-5VM5RSS4-BSe78hLa.js";import"./chunk-XXDRQBXY-DejEAIHt.js";import"./chunk-KBJHAD2P-DpDqhkHr.js";import"./chunk-2GRJ4B5K-BQ4pcmJ2.js";import"./channel-BzARkXrr.js";import"./index-fQPRatjV.js";import"./step-D2nkEwto.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
