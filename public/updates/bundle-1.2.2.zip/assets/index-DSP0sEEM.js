import{r as e}from"./index-fQPRatjV.js";const i=e("FileOpener");export{i as FileOpener};
