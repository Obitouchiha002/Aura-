const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-z8ENOmyS.js","assets/index-fQPRatjV.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-fQPRatjV.js";const _=p("App",{web:()=>r(()=>import("./web-z8ENOmyS.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
