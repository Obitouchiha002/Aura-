const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-17iIfGOk.js","assets/index-fQPRatjV.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-fQPRatjV.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-17iIfGOk.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
