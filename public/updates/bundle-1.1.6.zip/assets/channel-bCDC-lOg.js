import{U as a,R as n}from"./mermaid.core-jPBrUe3c.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
