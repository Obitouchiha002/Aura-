const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BODdxBQZ.js","assets/index-qAvoEj8Q.js","assets/index-CTAQN0ZA.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-qAvoEj8Q.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-BODdxBQZ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
