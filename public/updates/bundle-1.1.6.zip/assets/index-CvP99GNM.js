const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-pomlSonu.js","assets/index-qAvoEj8Q.js","assets/index-CTAQN0ZA.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-qAvoEj8Q.js";const _=p("App",{web:()=>r(()=>import("./web-pomlSonu.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
