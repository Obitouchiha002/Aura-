import{c as r,s as e}from"./flowDiagram-UKHOOZJN-dqjD2egS.js";import{_ as a}from"./mermaid.core-jPBrUe3c.js";import"./chunk-5VM5RSS4-wGheDE_H.js";import"./chunk-XXDRQBXY-B9h9Yz3f.js";import"./chunk-KBJHAD2P-H7zqAszD.js";import"./chunk-2GRJ4B5K-B-0cvy2q.js";import"./channel-bCDC-lOg.js";import"./index-qAvoEj8Q.js";import"./step-azJovCkv.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
