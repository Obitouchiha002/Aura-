import{r as e}from"./index-qAvoEj8Q.js";const i=e("FileOpener");export{i as FileOpener};
