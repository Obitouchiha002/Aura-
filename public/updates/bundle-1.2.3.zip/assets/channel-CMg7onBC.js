import{U as a,R as n}from"./mermaid.core-g3o3vdO2.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
