import{r as e}from"./index-BMzNOVUr.js";const i=e("FileOpener");export{i as FileOpener};
