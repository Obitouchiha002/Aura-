import{c as r,s as e}from"./flowDiagram-UKHOOZJN-BkT0i8IG.js";import{_ as a}from"./mermaid.core-g3o3vdO2.js";import"./chunk-5VM5RSS4-DLyooD6P.js";import"./chunk-XXDRQBXY-CdpsGloN.js";import"./chunk-KBJHAD2P-IFlf5rln.js";import"./chunk-2GRJ4B5K-Bg4JUsQp.js";import"./channel-CMg7onBC.js";import"./index-BMzNOVUr.js";import"./step-D2nkEwto.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
