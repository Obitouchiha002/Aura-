const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CcF3pVGT.js","assets/index-BMzNOVUr.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BMzNOVUr.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CcF3pVGT.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
