const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DnTnMfTA.js","assets/index-BMzNOVUr.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BMzNOVUr.js";const _=p("App",{web:()=>r(()=>import("./web-DnTnMfTA.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
