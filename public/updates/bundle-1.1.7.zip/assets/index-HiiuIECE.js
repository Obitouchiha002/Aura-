import{r as e}from"./index-Bqz45kpM.js";const i=e("FileOpener");export{i as FileOpener};
