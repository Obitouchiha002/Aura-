import{c as r,s as e}from"./flowDiagram-UKHOOZJN-4BnVdDF7.js";import{_ as a}from"./mermaid.core-BTdMVV2d.js";import"./chunk-5VM5RSS4-C25kzzBp.js";import"./chunk-XXDRQBXY-BbXvcdmY.js";import"./chunk-KBJHAD2P-Ck7_9S0I.js";import"./chunk-2GRJ4B5K-DWA9Tltf.js";import"./channel-Bh1_hR-2.js";import"./index-Bqz45kpM.js";import"./step-D2nkEwto.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
