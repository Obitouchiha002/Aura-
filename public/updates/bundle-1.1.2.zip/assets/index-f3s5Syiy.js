const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-COktnuD9.js","assets/index-BmTnTJJe.js","assets/index-CO3_wt1s.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BmTnTJJe.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-COktnuD9.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
