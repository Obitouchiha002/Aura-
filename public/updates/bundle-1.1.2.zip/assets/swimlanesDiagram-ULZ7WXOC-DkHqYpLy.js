import{c as r,s as e}from"./flowDiagram-UKHOOZJN-45OkSYIU.js";import{_ as a}from"./mermaid.core-DwirW7Bj.js";import"./chunk-5VM5RSS4-D6XvQWT2.js";import"./chunk-XXDRQBXY-DcO2vnWj.js";import"./chunk-KBJHAD2P-D4Mj7yMy.js";import"./chunk-2GRJ4B5K-Be3tb3Xm.js";import"./channel-B9kOIh2a.js";import"./index-BmTnTJJe.js";import"./step-azJovCkv.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
