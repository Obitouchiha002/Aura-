import{r as e}from"./index-BmTnTJJe.js";const i=e("FileOpener");export{i as FileOpener};
