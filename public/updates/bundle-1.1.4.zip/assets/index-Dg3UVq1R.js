const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CQ-Ankjl.js","assets/index-DY8K2VyK.js","assets/index-DT8rhUW6.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-DY8K2VyK.js";const _=p("App",{web:()=>r(()=>import("./web-CQ-Ankjl.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
