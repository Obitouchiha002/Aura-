import{r as e}from"./index-DY8K2VyK.js";const i=e("FileOpener");export{i as FileOpener};
