import{c as r,s as e}from"./flowDiagram-UKHOOZJN-C2LugQNK.js";import{_ as a}from"./mermaid.core-B6sxvlRK.js";import"./chunk-5VM5RSS4-BhwQnhhr.js";import"./chunk-XXDRQBXY-D5Wei0g3.js";import"./chunk-KBJHAD2P-CCqw5Yil.js";import"./chunk-2GRJ4B5K-DbExq5_L.js";import"./channel-CsXGtRdx.js";import"./index-DY8K2VyK.js";import"./step-azJovCkv.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
