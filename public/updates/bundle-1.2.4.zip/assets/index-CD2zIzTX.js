const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BtVo2-go.js","assets/index-PhXa85u7.js","assets/index-CmZ_DDre.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-PhXa85u7.js";const _=p("App",{web:()=>r(()=>import("./web-BtVo2-go.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
