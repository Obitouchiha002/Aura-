import{r as e}from"./index-PhXa85u7.js";const i=e("FileOpener");export{i as FileOpener};
