import{W as n}from"./index-PhXa85u7.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
