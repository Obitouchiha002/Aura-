import{c as r,s as e}from"./flowDiagram-UKHOOZJN-CcfOJXD9.js";import{_ as a}from"./mermaid.core-BBBeO2NW.js";import"./chunk-5VM5RSS4-6y9Dn4Cr.js";import"./chunk-XXDRQBXY-ticNwmBt.js";import"./chunk-KBJHAD2P-_LACG_R3.js";import"./chunk-2GRJ4B5K-PqzpFLWQ.js";import"./channel-Bs9843fR.js";import"./index-PhXa85u7.js";import"./step-D2nkEwto.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
