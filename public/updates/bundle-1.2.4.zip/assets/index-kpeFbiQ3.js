const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CCMR4jsM.js","assets/index-PhXa85u7.js","assets/index-CmZ_DDre.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-PhXa85u7.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CCMR4jsM.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
