const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CO8sUBwU.js","assets/index-CaTc_EYc.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CaTc_EYc.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CO8sUBwU.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
