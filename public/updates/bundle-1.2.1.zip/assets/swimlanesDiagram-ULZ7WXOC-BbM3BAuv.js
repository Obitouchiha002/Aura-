import{c as r,s as e}from"./flowDiagram-UKHOOZJN-D1hx5U1e.js";import{_ as a}from"./mermaid.core-BC3hHADS.js";import"./chunk-5VM5RSS4-C5Ibv7aq.js";import"./chunk-XXDRQBXY-BKVxodoW.js";import"./chunk-KBJHAD2P-CPAPiUU6.js";import"./chunk-2GRJ4B5K-CYqPQCuH.js";import"./channel-B6-SEJCt.js";import"./index-CaTc_EYc.js";import"./step-D2nkEwto.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
