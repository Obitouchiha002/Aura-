import{U as a,P as n}from"./mermaid.core-BC3hHADS.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
