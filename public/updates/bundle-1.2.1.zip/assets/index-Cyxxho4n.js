import{r as e}from"./index-CaTc_EYc.js";const i=e("FileOpener");export{i as FileOpener};
