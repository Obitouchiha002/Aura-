const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DYieyFEz.js","assets/index-CaTc_EYc.js","assets/index-DMN8WBXj.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-CaTc_EYc.js";const _=p("App",{web:()=>r(()=>import("./web-DYieyFEz.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
